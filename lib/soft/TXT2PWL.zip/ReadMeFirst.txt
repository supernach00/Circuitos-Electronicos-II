----------------------------------------------------------------------------
TXT2PWL SOFTWARE Ver1.0 by Paulo Valongo (paulovalongo@rocketmail.com)
----------------------------------------------------------------------------

TXT2PWL is a quick program I wrote to make the task of creating custom
waveform files (pwl) for LTSPICE easier and less error prone.
I have used it sucessfully for my own simulations and decided to release 
it as freeware in the hope it will be as usefull to others.

The program is limited to creating only square (digital) waveforms
with  HI and LO logic levels. (i.e. it cannot create analog waveforms
with multiple shapes and voltage levels).

When I have more time, perhaps I will create another program with
more advanced features, but for now this serves my purpose.

For terms of use and further information, please refer to TXT2PWL.pdf

To use the software, simply unzip this file (which you already have 
otherwise you wouldn't be reading this) and extract all the files to
any directory of your choice.
That's it, you're good to go.

The program is written in VB6 so it has the usual dependencies such as
VBRUN600.dll and comctl2.ocx but these you should already have on your
Windows XP machine.(every machine with XP I've used had them).
Don't know about Vista.

I have not included them here to keep file size down to a minimum.

---------------------
Contents of Zip file:
---------------------

TXT2PWL.exe

TXT2PWL.pdf
TXT2PWL_known_bugs.pdf

Example1.txt
Example1.mwf

Example2.txt
Example2.mwf

TestPwlExample1.asc

ReadMeFirst.txt   (This file)
